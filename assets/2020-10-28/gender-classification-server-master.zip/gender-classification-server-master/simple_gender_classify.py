from keras.models import load_model

import tensorflow as tf
import PIL.Image
import numpy as np

from utils.preprocessor import preprocess_input


class SimpleGenderClassifier:
    def __init__(self):
        self.gender_model_path = 'trained_models/simple_CNN.81-0.96.hdf5'
        self.gender_labels = ['female', 'male']

        self.gender_offsets = (10, 10)

        # loading models
        self.sess = tf.Session()
        self.graph = tf.get_default_graph()
        tf.keras.backend.set_session(self.sess)
        self.gender_classifier = load_model(self.gender_model_path, compile=False)
 

        # getting input model shapes for inference
        self.gender_target_size = self.gender_classifier.input_shape[1:3]

    def classify(self, image: PIL.Image):
        resized_image = image.resize(self.gender_target_size)
        resized_image_arr = np.array(resized_image)
        resized_image_arr = preprocess_input(resized_image_arr, False)
        resized_image_arr = np.expand_dims(resized_image_arr, 0)

        with self.graph.as_default():
            tf.keras.backend.set_session(self.sess)
            [gender_prediction] = self.gender_classifier.predict(resized_image_arr)

        return {
            'result': dict(zip(self.gender_labels, gender_prediction.tolist()))
        }
