from flask import Flask, request, make_response, jsonify, abort
import logging
import PIL.Image
import io
from gender_classify import GenderClassifier
from simple_gender_classify import SimpleGenderClassifier

app = Flask(__name__)
classifier = SimpleGenderClassifier()


@app.route('/', methods=['POST'])
def serving():
    try:
        # input_image_bytes = request.files['image'].read()
        input_image_bytes = request.get_data()
        src_image = PIL.Image.open(io.BytesIO(input_image_bytes))
        result = classifier.classify(src_image)
        print(result)
        return jsonify(result)
    except Exception as err:
        logging.error('An error has occurred whilst processing the file: "{0}"'.format(err))
        abort(400)


@app.errorhandler(400)
def bad_request(erro):
    return make_response(jsonify({'error': 'We cannot process the file sent in the request.'}), 400)


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Resource no found.'}), 404)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8084)
