# gender-classification-server


## Requirment:

`pip install -r requirements.txt`

## Start server:
`python app.py`
