import logging
import traceback

import cv2
from keras.models import load_model
import tensorflow as tf
import numpy as np

from utils.inference import detect_faces
from utils.inference import apply_offsets
from utils.inference import load_detection_model
from utils.preprocessor import preprocess_input


class GenderClassifier():
    def __init__(self):
        self.detection_model_path = 'trained_models/haarcascade_frontalface_default.xml'
        self.gender_model_path = 'trained_models/simple_CNN.81-0.96.hdf5'
        self.gender_labels = ['female', 'male']

        self.gender_offsets = (10, 10)

        # loading models
        self.face_detection = load_detection_model(self.detection_model_path)
        self.gender_classifier = load_model(self.gender_model_path, compile=False)
        self.graph = tf.get_default_graph()

        # getting input model shapes for inference
        self.gender_target_size = self.gender_classifier.input_shape[1:3]

    def classify(self, image):
        try:
            # loading images
            image_array = np.fromstring(image, np.uint8)
            unchanged_image = cv2.imdecode(image_array, cv2.IMREAD_UNCHANGED)

            rgb_image = cv2.cvtColor(unchanged_image, cv2.COLOR_BGR2RGB)
            gray_image = cv2.cvtColor(unchanged_image, cv2.COLOR_BGR2GRAY)

            faces = detect_faces(self.face_detection, gray_image)

            if len(faces) == 0:
                return {'error': 'No face found'}

            if len(faces) > 1:
                return {'error': 'More than one face in image.'}

            face_coordinates = faces[0]
            x1, x2, y1, y2 = apply_offsets(face_coordinates, self.gender_offsets)
            rgb_face = rgb_image[y1:y2, x1:x2]
            rgb_face = cv2.resize(rgb_face, (self.gender_target_size))

            rgb_face = preprocess_input(rgb_face, False)
            rgb_face = np.expand_dims(rgb_face, 0)
            with self.graph.as_default():
                [gender_prediction] = self.gender_classifier.predict(rgb_face)

            return {
                'result': dict(zip(self.gender_labels, gender_prediction.tolist()))
            }

        except Exception as err:
            traceback.print_exc()
            return {'error': err}
            # logging.error('Error in emotion gender processor: "{0}"'.format(err))
