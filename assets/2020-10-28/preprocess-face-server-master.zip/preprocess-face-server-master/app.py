import PIL.Image
import io
import traceback

from flask import Flask, request, make_response, jsonify, abort
from align_face_ffhq.face_aligner import FaceAligner

app = Flask(__name__)
face_aligner = FaceAligner()


@app.route('/')
def hello_world():
    return 'Preprocess face for StarGANv2 API!'


@app.route('/', methods=['POST'])
def serving():
    try:
        input_image_bytes = request.get_data()
        src_image = PIL.Image.open(io.BytesIO(input_image_bytes))
        cropped_image, error_message = face_aligner.align(src_image)

        if error_message is not None:
            print(error_message)
            return make_response(jsonify({'error': error_message}), 204)    # 204: No content

        bytesio = io.BytesIO()
        cropped_image.save(bytesio, format='jpeg')
        output_image_bytes = bytesio.getvalue()

        response = make_response(output_image_bytes)
        response.headers.set('Content-Type', 'image/jpeg')
        return response

    except Exception as err:
        traceback.print_exc()
        abort(400)


@app.errorhandler(400)
def bad_request(error):
    return make_response(jsonify({'error': 'We cannot process the file sent in the request.'}), 400)


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Resource no found.'}), 404)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8085)
