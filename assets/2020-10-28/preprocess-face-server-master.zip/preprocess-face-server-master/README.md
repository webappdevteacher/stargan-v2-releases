# preprocess-face-server

_Note:_

After clone this repo, if your **align_face_ffhq** folder is empty, just run this command:

`git submodule update --init --recursive`

## Requirment:

`pip install -r requirements.txt`

## Start server:

`python app.py`
